package com.example.googleads3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements RewardedVideoAdListener {

    Button mButton;
    TextView mLog;
    RewardedVideoAd mAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mLog=findViewById(R.id.textView);
        mButton=findViewById(R.id.button);
        mButton.setEnabled(false);

        MobileAds.initialize(this, "ca-app-pub-3940256099942544~3347511713");   // App Id Object

        mAd=MobileAds.getRewardedVideoAdInstance(this);        //getter and setter Instance of getReward
        mAd.setRewardedVideoAdListener(this);

        mAd.loadAd("ca-app-pub-3940256099942544/5224354917",
                new AdRequest.Builder().build());           // Ad Test Unit Id & Request

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mButton.setEnabled(false);
                if(mAd.isLoaded()){
                    mAd.show();               //Load Ad
                }                             // show Ad

            }
        });
    }


    // CallBack Methods

    @Override
    public void onRewardedVideoAdLoaded() {
        mLog.append("An Ad has Loaded.\n");
        mButton.setEnabled(true);
    }

    @Override
    public void onRewardedVideoAdOpened() {
        mLog.append("An Ad has Opened.\n");
    }

    @Override
    public void onRewardedVideoStarted() {
        mLog.append("An Ad has Started.\n");
    }

    @Override
    public void onRewardedVideoAdClosed() {
        mLog.append("An Ad has Closed.\n");
    }

    @Override
    public void onRewarded(RewardItem rewardItem) {

        mLog.append(String.format(Locale.getDefault(),
                "You Received %d %s!\n",rewardItem.getAmount(),rewardItem.getType()));    // Shows Reward yo User
    }

    @Override
    public void onRewardedVideoAdLeftApplication() {
        mLog.append("An Ad has caused Focus to Leave.\n");
    }

    @Override
    public void onRewardedVideoAdFailedToLoad(int i) {
        mLog.append("An Ad has Failed to Load.\n");
    }
}
